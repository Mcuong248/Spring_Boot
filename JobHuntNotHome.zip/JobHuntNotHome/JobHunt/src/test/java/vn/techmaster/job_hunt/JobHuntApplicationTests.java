package vn.techmaster.job_hunt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobHuntApplicationTests {

	@Test
	void contextLoads() {
	}

}
