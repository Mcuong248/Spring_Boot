package vn.techmaster.demosession.model;

public enum State {
    PENDING,
    ACTIVE,
    DISABLED,
    REMOVED;
}
