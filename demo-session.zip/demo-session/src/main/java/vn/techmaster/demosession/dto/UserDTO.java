package vn.techmaster.demosession.dto;

public record UserDTO(String id, String fullName, String email) {
    
}
